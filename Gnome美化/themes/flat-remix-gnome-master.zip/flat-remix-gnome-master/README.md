![Flat Remix GNOME theme](https://github.com/daniruiz/flat-remix-gnome/raw/master/assets/logo.png)
===============================

# More information at [drasite.com/flat-remix-gnome](https://drasite.com/flat-remix-gnome)

![theme preview](https://github.com/daniruiz/flat-remix-gnome/raw/master/assets/GNOME-40.png)

![theme preview](https://github.com/daniruiz/flat-remix-gnome/raw/master/assets/preview.png)
